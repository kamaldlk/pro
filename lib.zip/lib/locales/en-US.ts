/* eslint-disable import/no-anonymous-default-export */
import settingDrawer from './en-US/settingDrawer';

export default {
  ...settingDrawer,
};
