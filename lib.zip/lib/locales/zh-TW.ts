/* eslint-disable import/no-anonymous-default-export */
import settingDrawer from './zh-TW/settingDrawer';

export default {
  ...settingDrawer,
};
