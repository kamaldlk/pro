/* eslint-disable import/no-anonymous-default-export */
import settingDrawer from './it-IT/settingDrawer';

export default {
  ...settingDrawer,
};
