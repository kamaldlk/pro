/* eslint-disable import/no-anonymous-default-export */
import settingDrawer from './zh-CN/settingDrawer';

export default {
  ...settingDrawer,
};
